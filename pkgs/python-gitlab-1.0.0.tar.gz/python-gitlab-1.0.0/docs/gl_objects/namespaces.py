# list
namespaces = gl.namespaces.list()
# end list

# search
namespaces = gl.namespaces.list(search='foo')
# end search
