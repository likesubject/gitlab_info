# list
deployments = project.deployments.list()
# end list

# get
deployment = project.deployments.get(deployment_id)
# end get
