# get
settings = gl.settings.get()
# end get

# update
s.signin_enabled = False
s.save()
# end update
